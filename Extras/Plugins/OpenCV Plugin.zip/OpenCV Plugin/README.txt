
This is a simple plugin that integrates OpenCV 3.0.0 to UE4. The author is in no way affiliated with OpenCV, and their library can be found for free at http://opencv.org/.  This plugin is made by the UE4 community, and does not mean that OpenCV endorses UE4 in any way.

Installation Instructions:

-unzip this folder
-add the Binaries, Plugins, and ThirdParty folders to your UE4 project (merge if prompted)
-launch the project
-navagate to Edit->Plugins and find the OpenCV plugin in the Computer Vision category under the Project plugins
-Check enabled and restart the editor
-Be sure to include the 'OpenCV' public dependency in your project's Build.CS file