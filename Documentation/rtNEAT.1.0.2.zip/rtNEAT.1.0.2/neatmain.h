extern double *testdoub;







